$(function() {
    "use strict";
});
